#!/usr/bin/env python3
"""Offline independent descriptive check of archived RQ3 development labels."""
from pathlib import Path
from zipfile import ZipFile
from io import BytesIO
import pandas as pd,json,sys
root=Path(__file__).resolve().parents[1]
archive=root/'02_IMMUTABLE_EVIDENCE_20261108.zip'
with ZipFile(archive) as z:
    p=[p for p in z.namelist() if p.endswith('/marginal_work_training.csv')]
    assert len(p)==1,p
    df=pd.read_csv(BytesIO(z.read(p[0])))
assert len(df)==1948
by_seed=df.groupby('seed').agg(n=('positive','size'),positive=('positive','sum'),saving_nodes=('saving_nodes','sum')).sort_values('saving_nodes',ascending=False)
result={'n_rows':len(df),'n_seeds':len(by_seed),'n_positive':int(df.positive.sum()),'n_seeds_with_positive':int((by_seed.positive>0).sum()),'saving_nodes_total':int(df.saving_nodes.sum()),'top_three_seed_saving_share':float(by_seed.saving_nodes.head(3).sum()/df.saving_nodes.sum()),'constant_features':[c for c in ['invested_nodes_norm','stored_gap_finite'] if df[c].nunique(dropna=False)==1]}
print(json.dumps(result,indent=2))
if len(sys.argv)>1:Path(sys.argv[1]).write_text(json.dumps(result,indent=2)+'\n')
