#!/usr/bin/env python3
"""Post-hoc late-horizon label audit from unchanged original RQ3 development CSV. Standard library only."""
import csv,io,zipfile,hashlib,json,sys,collections
from pathlib import Path
root=Path(__file__).resolve().parents[1]
archive=root/'02_IMMUTABLE_EVIDENCE_20261108.zip'
path='Finite_Memory_Exact_Search_Submission_20261108/04_Results/RQ3/VM90_and_Model/01_Development_Model/marginal_work_training.csv'
with zipfile.ZipFile(archive) as z: data=z.read(path)
expected='310795883e92467f411fc8387b9c740bb8bc6e46efcbad6ac14a780547147cb5'
if hashlib.sha256(data).hexdigest()!=expected:raise RuntimeError('original input SHA-256 does not match')
rows=list(csv.DictReader(io.StringIO(data.decode('utf-8-sig'))))
late=[r for r in rows if int(r['created_iteration'])>160]
late_none=[r for r in late if r['event']=='none']
none=[r for r in rows if r['event']=='none']
positive=[r for r in rows if float(r['saving_nodes'])>0]
result={'method':'retrospective horizon completeness audit; no relabeling, no new model fit','horizon':40,'last_observed_iteration':200,'original_sha256':expected,'total_candidates':len(rows),'total_seeds':len({r['seed'] for r in rows}),'positive_saving_labels':len(positive),'none_event_labels':len(none),'post_iteration_160_all_events':len(late),'post_iteration_160_none_events':len(late_none),'affected_seeds':len({r['seed'] for r in late_none}),'fraction_none_events_potentially_censored':len(late_none)/len(none),'not_a_claim_that_labels_are_wrong':True}
assert (result['total_candidates'],result['total_seeds'],result['positive_saving_labels'],result['none_event_labels'],result['post_iteration_160_all_events'],result['post_iteration_160_none_events'],result['affected_seeds'])==(1948,25,73,311,367,121,24)
print(json.dumps(result,indent=2))
if len(sys.argv)>1:Path(sys.argv[1]).write_text(json.dumps(result,indent=2)+'\n')
