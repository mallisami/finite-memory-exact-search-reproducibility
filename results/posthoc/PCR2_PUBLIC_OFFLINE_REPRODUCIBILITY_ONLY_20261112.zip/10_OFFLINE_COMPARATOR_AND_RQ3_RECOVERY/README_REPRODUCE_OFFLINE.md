# Reproduce the offline comparator checks without cloud VMs

The authoritative current main manuscript and Online Resource 1 are in `../01_CURRENT_MANUSCRIPT/`; they are **unchanged from R3**. This annex is a provenance-only repair and a bounded source search, not new scientific results.

From the annex directory, on a machine with Python, NumPy, pandas, SciPy and pytest installed:

```bash
python verify_retained_comparators.py
cd frozen_source
PYTHONPATH=. python -m pytest tests/test_external_eviction.py -q
PYTHONPATH=. python replay_spot_checks.py
```

The first command audits all 945 historical FIFO/LRU/random run records, all 405 case-policy-budget rows, and 36 published aggregate mean cells. The second executes 5 unit tests. The third re-executes **three previously recorded** 200-iteration cases on the frozen historical solver code and compares 15 deterministic counters in each (generic/FIFO at 25%, workflow/LRU at 50%, microservice/random at 75%). It takes CPU time on the local machine and prints its findings. **Do not compare local timing numbers to archived VM times.** These steps are read-only; snapshot receipts are included in the annex.

To repeat the original code-file search when your standalone `Path A.zip` is available, run from the annex directory (write outputs to a directory outside the release):

```bash
python scan_rq3_source_provenance.py --original ../02_IMMUTABLE_EVIDENCE_20261108.zip --path-a "/path/to/Path A.zip" --out /tmp/pcr2_source_scan
```

The original RQ3 label-producing script was not identified in the accessible archives. `RQ3_SOURCE_SEARCH_SUMMARY.json` records a scan of 1,433 Python code-file instances in the original author ZIP, `Path A.zip`, and accessible nested archives (including duplicate scripts), with 25 target-token matching instances. These hits were consumers, post-hoc analyzers, or reconstruction studies, not the original production driver. The full uploaded 235 MB `Path A.zip` is not included in this release to avoid double-packaging older experiments; the scan receipt is preserved and identifies its exact hash.

The original 1,948-row RQ3 label table remains byte-identical in `../02_IMMUTABLE_EVIDENCE_20261108.zip`. No unobserved labels are synthesized, no retraining performed, and no missing future trajectories are claimed recovered.

**Limitations:** We did not rerun the entire historical 945-run comparator campaign, recapture deleted VM time, verify every legacy runtime component, or identify a published external policy whose semantic objects exactly match unfinished serialized branch-and-bound frontiers. The manuscript already reports traditional eviction baselines, which should not be relabeled as a verbatim implementation of another paper's algorithm.
