#!/usr/bin/env python3
"""Independent retained-CSV audit of published FIFO/LRU/random P7 comparators.
Does not reproduce VM runtime or generate new scientific samples.
"""
from pathlib import Path
import hashlib,json
import pandas as pd
import numpy as np
P=Path(__file__).resolve().parent/'retained_comparator_data'
df=pd.read_csv(P/'p7_external_comparator_runs.csv')
case=pd.read_csv(P/'p7_external_comparator_case_level.csv')
agg=pd.read_csv(P/'p7_external_comparator_aggregate.csv')
assert len(df)==945,len(df)
assert len(case)==405,len(case)
assert set(df.policy)=={'fifo','lru','random'}
assert set(df.domain)=={'generic','workflow','microservice'}
assert df.instance_seed.nunique()==15
assert set(np.round(df.budget_fraction,2))=={.25,.50,.75}
assert len(df[df.policy=='fifo'])==135 and len(df[df.policy=='lru'])==135 and len(df[df.policy=='random'])==675
assert df.task_id.nunique()==945
assert (df.budget_bytes >= df.peak_bytes).all()
assert (df.not_retained==0).all()
assert (df.iterations==200).all()
assert df.timing_fields_inferentially_valid.eq(False).all()
rand=df[df.policy=='random'].groupby(['domain','instance_seed','budget_fraction']).agg(n=('eviction_seed','size'),distinct=('eviction_seed','nunique'))
assert (rand.n==5).all() and (rand.distinct==5).all() and len(rand)==135
assert (case.groupby(['budget_fraction','policy']).size()==45).all()
# independently check aggregation of retained case-level observations
checks=[]
for _,r in agg.iterrows():
 g=case[(case.budget_fraction==r.budget_fraction)&(case.policy==r.policy)]
 for field in ['reuse_fraction_of_keep_all','reused_prior_branch_pops','useful_resumes','avoided_branch_pops_vs_restart']:
  observed=float(g[field].mean());stored=float(r['mean_'+field]);assert abs(observed-stored)<1e-9,(r.budget_fraction,r.policy,field,observed,stored)
  checks.append({'budget_fraction':r.budget_fraction,'policy':r.policy,'metric':field,'recalculated_mean':observed,'original_mean':stored})
report={'raw_rows':len(df),'collapsed_case_policy_budget_rows':len(case),'independent_cases':45,'budgets':[.25,.50,.75],'random_repetitions_per_case_budget':5,'budget_violations':int((df.peak_bytes>df.budget_bytes).sum()),'duplicate_tasks':int(df.task_id.duplicated().sum()),'aggregate_numeric_means_checked':len(checks),'timing_fields_inferentially_valid':False,'source_csv_sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in [P/'p7_external_comparator_runs.csv',P/'p7_external_comparator_case_level.csv',P/'p7_external_comparator_aggregate.csv']},'outcome':'PASS for retained CSV consistency, not full historical campaign replay'}
# read-only verifier: the historical receipt is retained separately
print(json.dumps(report,indent=2))
