#!/usr/bin/env python3
"""Read-only scoped provenance search. The absence of a hit does not prove nonexistence of unarchived code."""
import argparse, csv, hashlib, io, json, re, tarfile, zipfile
from pathlib import Path
PATS={
  'training_filename':re.compile('marginal_work_training(?:\\.csv)?',re.I),
  'saving_nodes':re.compile(r'\bsaving_nodes\b',re.I),
  'event_features':re.compile(r'\brecurrence_delay\b|\binvested_nodes_norm\b',re.I),
}
rows=[]; totals={'python_instances_scanned':0,'nested_archive_instances_scanned':0,'skipped':[]}

def visit_script(data, location):
 if len(data)>2_000_000:return
 totals['python_instances_scanned']+=1
 s=data.decode('utf-8','replace')
 hits={key for key, pat in PATS.items() if pat.search(s)}
 if hits & {'training_filename','saving_nodes'}:
  lines=[{'line':i,'text':line.strip()[:180]} for i,line in enumerate(s.splitlines(),1)
         if PATS['training_filename'].search(line) or PATS['saving_nodes'].search(line)]
  rows.append({'location':location,'sha256':hashlib.sha256(data).hexdigest(),'tokens':';'.join(sorted(hits)),'lines':lines[:20]})

def visit_tar(data, location):
 try:
  with tarfile.open(fileobj=io.BytesIO(data),mode='r:*') as z:
   totals['nested_archive_instances_scanned']+=1
   for info in z:
    if info.isfile() and info.name.endswith('.py') and info.size<=2_000_000:
     f=z.extractfile(info)
     if f:visit_script(f.read(),location+'::'+info.name)
 except (tarfile.TarError,OSError) as e: totals['skipped'].append(location+':'+str(e)[:60])

def visit_zip(z,location,depth=0):
 for info in z.infolist():
  n=info.filename
  if n.endswith('.py') and info.file_size<=2_000_000:visit_script(z.read(info),location+'::'+n)
  if depth>=2 or not n.lower().endswith(('.zip','.tar.gz','.tgz','.tar')):continue
  if info.file_size>115_000_000:
   totals['skipped'].append(location+'::'+n+': over size threshold');continue
  raw=z.read(info)
  if n.lower().endswith('.zip'):
   try:
    with zipfile.ZipFile(io.BytesIO(raw)) as nested:
     totals['nested_archive_instances_scanned']+=1
     visit_zip(nested,location+'::'+n,depth+1)
   except (zipfile.BadZipFile,OSError) as e: totals['skipped'].append(location+'::'+n+':'+str(e)[:60])
  else:visit_tar(raw,location+'::'+n)

p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--original',required=True,type=Path,help='November 8 immutable author archive')
p.add_argument('--path-a',type=Path,help='Optional external Path A.zip archive; not duplicated in reviewer release')
p.add_argument('--out',type=Path,help='Optional directory for JSON/CSV reports (outside verified release)')
a=p.parse_args()
archives=[a.original]+([a.path_a] if a.path_a else [])
for f in archives:
 with zipfile.ZipFile(f) as z:visit_zip(z,f.name)
report={**totals,'archive_inputs':[{'filename':x.name,'sha256':hashlib.sha256(x.read_bytes()).hexdigest()} for x in archives], 'target_token_matches':len(rows),'interpretation':'Matches require manual classification; consumers and post-hoc reconstructors are not evidence of the original producer.'}
print(json.dumps(report,indent=2))
if a.out:
 a.out.mkdir(parents=True,exist_ok=True)
 (a.out/'search_summary.json').write_text(json.dumps(report,indent=2)+'\n')
 with (a.out/'search_hits.csv').open('w',newline='') as f:
  w=csv.DictWriter(f,['location','sha256','tokens','line_evidence']);w.writeheader()
  for row in rows:w.writerow({'location':row['location'],'sha256':row['sha256'],'tokens':row['tokens'],'line_evidence':json.dumps(row['lines'])})
