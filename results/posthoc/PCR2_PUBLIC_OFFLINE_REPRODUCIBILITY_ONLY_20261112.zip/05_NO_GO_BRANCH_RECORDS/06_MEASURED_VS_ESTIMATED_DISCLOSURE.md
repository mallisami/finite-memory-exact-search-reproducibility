# Disclosure of Directly Measured vs. Analytically Estimated Metrics

In accordance with strict scientific forensic standards, this document distinguishes all directly measured experimental quantities from derived analytical estimates.

---

## 1. Directly Measured Quantities

The following values were instrumented and directly recorded by the benchmarking harness (`test_all_p7_v6.py`, log `task-872.log`):

1. **Wall-Clock Time**:
   - `t_emp`: Measured via `time.perf_counter()` before and after `run_online_replay(policy='empirical_compatible')`.
   - `t_dir`: Measured via `time.perf_counter()` before and after `run_online_replay(policy='learned', predictor=pred)`.
   - `t_casc`: Measured via `time.perf_counter()` before and after `run_online_replay(policy='learned', predictor=pred)` with `OnlineStepPolicy = CascadedOnlineStepPolicy`.
2. **Useful Resumes**:
   - `r_emp.useful_resumes`: Directly counted by `P7PilotResult.useful_resumes`.
   - `r_dir.useful_resumes`: Directly counted by `P7PilotResult.useful_resumes`.
   - `r_casc.useful_resumes`: Directly counted by `P7PilotResult.useful_resumes`.
3. **Model Scoring Calls**:
   - `r_dir.model_scoring_calls`: Directly counted by `OnlineStepPolicy.model_scoring_calls`.
   - `r_casc.model_scoring_calls`: Directly counted by `CascadedOnlineStepPolicy.model_scoring_calls`.

---

## 2. Analytically Estimated Quantities (Not Directly Exported Columns)

The following values mentioned in discussions or earlier reports were **derived estimates**, not column-level telemetry:

1. **The 25.5 ms Recomputation Penalty**:
   - **Status**: **ANALYTICAL ESTIMATE.**
   - **Derivation**: In the earlier framework document (`OPTION_B_CASCADED_GATING_EXPERIMENT_AND_DECISION_FRAMEWORK.md`), the 25.5 ms figure was computed as:
     $$\text{Estimated Penalty} = \overline{\Delta \text{Resumes}} \times \overline{T_{\text{slice repair}}} = 3.0 \times 8.5\,\text{ms} = 25.5\,\text{ms}$$
   - It was **not** a separate column output from a timer in `test_all_p7_v6.py`.
2. **Component Sub-Timers in Option B**:
   - `restoration_ms`, `serialization_ms`, `selection_ms`, and `history_feature_ms` are internal attributes of `P7PilotResult`.
   - In `test_all_p7_v6.py`, these internal sub-timers were computed by the underlying C/Python runner but were not extracted or printed in the stdout loop.
   - Therefore, while total wall-time and useful resumes are directly verified, individual sub-millisecond breakdown times for the Option B test are classified as **not exported to CSV/JSON in the original runner**.

---

## 3. Solver Correctness and Objective Quality

* In all 10 cases, the ALNS search completed all 200 iterations.
* All generated moves, slice evaluations, and solution updates conformed to the problem constraints.
* Final best objective values were valid and preserved across all three arms.
