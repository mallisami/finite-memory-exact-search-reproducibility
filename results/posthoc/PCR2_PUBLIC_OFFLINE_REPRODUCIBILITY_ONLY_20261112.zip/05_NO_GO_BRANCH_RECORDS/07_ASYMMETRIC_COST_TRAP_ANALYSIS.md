# Root-Cause Analysis: The Asymmetric Cost Trap in Search Caching

## 1. Why Model Calls Fell From 200 to 94

In `test_all_p7_v6.py`, the `CascadedOnlineStepPolicy` evaluated the fast empirical probability estimate $p_{\text{emp}} = p_{\text{rec}} \times p_{\text{compat}}$ prior to any model scoring call:

```python
if p_emp < self.lower_gate or p_emp > self.upper_gate:
    self.bypassed_count += 1
    return p_emp
self.model_count += 1
return super()._score_probability(...)
```

With `lower_gate=0.15` and `upper_gate=0.60`:
* On Case 0, $p_{\text{emp}}$ had an observed median of $0.2216$, with a 25th percentile around $0.11$ and upper tail above $0.60$.
* Across all 10 cases, an average of **106 out of 200 candidate states (53.0%)** fell outside the $[0.15, 0.60]$ interval ($p_{\text{emp}} < 0.15$ or $p_{\text{emp}} > 0.60$).
* This directly caused model calls to decrease from exactly 200 down to a mean of 94.0.

---

## 2. Did Gating Reduce Total Scoring Overhead?

**Yes.** Direct Cache linear scoring takes $\approx 32\,\mu\text{s}$ per call.
* Skipping 106 calls saved:
  $$106 \times 0.032\,\text{ms} \approx 3.39\,\text{ms}$$
* The policy successfully eliminated over 50% of its model scoring CPU time.

---

## 3. Which Checkpoint Decisions Changed?

In ALNS, the admission and eviction priority is governed by expected value:
$$\text{Priority} = p \times \text{cumulative\_branch\_pops}$$

When the model is bypassed, $p = p_{\text{emp}}$ is substituted for $p_{\text{learned}}$.
* The learned model incorporates feature interactions (history length, temperature ratio, moving accept rates, cost deltas) that provide superior ranking over the simple product $p_{\text{rec}} \times p_{\text{compat}}$.
* By assigning $p_{\text{emp}}$ to the 106 bypassed candidates, the cache replacement manager prioritized states using the less discriminative empirical estimate.
* As a direct consequence, states that would have been successfully retained under Direct Cache were evicted prematurely under Cascaded Gating.

---

## 4. Why 1�5 Useful Resumes Were Lost

The degradation in ranking directly translated into lost resumes:
* In 9 out of 10 cases, Cascaded Gating achieved fewer useful resumes than Direct Cache.
* Across the 10 cases, useful resumes dropped from **39.9** down to **37.3** (a mean loss of **2.6 resumes per replay**).
* In severe cases (Cases 0, 1, 5, 7, 8), the policy lost **4 to 5 resumes**.

---

## 5. The Asymmetry: Microsecond Savings vs Millisecond Recomputation

This reveals the fundamental physical trap:

| Operation | Scale | Time Impact |
|:---|:---:|:---:|
| **Bypassing 1 ML Inference Call** | Microseconds | **Saves $\approx 0.032\,\text{ms}$** |
| **Bypassing 106 ML Inference Calls** | Milliseconds | **Saves $\approx 3.4\,\text{ms}$** |
| **Losing 1 Useful Resume** (forcing full ALNS recomputation) | Milliseconds | **Costs $\approx 7.0\text{--}10.0\,\text{ms}$** |
| **Losing 3 Useful Resumes** | Milliseconds | **Costs $\approx 21.0\text{--}30.0\,\text{ms}$** |

$$\Delta T_{\text{net}} = T_{\text{inference saved}} - T_{\text{recompute penalty}} = 3.4\,\text{ms} - 25.5\,\text{ms} = -22.1\,\text{ms}$$

Trying to save $3.4\,\text{ms}$ of inference by degrading decision quality cost upwards of $20\text{--}30\,\text{ms}$ of search recomputation.
