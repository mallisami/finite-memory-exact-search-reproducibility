# R3 post-hoc diagnostics: original evidence only

The script here is an **analysis of retained data**, not an executed experiment. It does not train a new model, overwrite labels, alter the raw evidence, or implement the stopped Path A/B development algorithms.

## Reproduction

From the **extracted outer R3 release root** (Python 3 with `numpy`, `pandas`, `scikit-learn`):

```bash
python 09_POSTHOC_P0_DIAGNOSTICS_20261110/reanalyze_p0.py \
  --out /tmp/pcr2_p0_regenerated
```

The default input is `02_IMMUTABLE_EVIDENCE_20261108.zip` in the same outer release. The script independently checks its frozen SHA-256 and the original RQ3 training-CSV hash, validates original-vs-OOF row identity, and fails if expected population or policy-arm counts change. All numerical output JSON and diagnostic CSV files are regenerated into the chosen destination.

Verification examples:

```bash
python 06_REPRODUCE/verify_ssot.py --deep
python 06_REPRODUCE/reproduce_rq3_horizon_censoring.py
python 06_REPRODUCE/reproduce_rq3_sparsity.py
```

## Distinguishing analytic populations

- **Original 1,948-row RQ3 training table:** Used for new late-`none` exclusion and archived OOF-score sensitivity. The seed-disjoint OOF scores are from a *replacement diagnostic*; original historic fold assignments were unavailable.
- **Recovered 1,875-row RQ3 censor/quality reconstruction:** A different cohort and historical NO-GO development trial. Its 117 censored cases are **not** the 121 original-table late no-recurrence rows. Do not pool or equate them.
- **P7 45-case controller component analysis:** Six within-run instrumented components, not full wall time.
- **MDKP VM90 90-case analysis:** Five-repeat case medians; matched policy comparisons by fixed case; 30 cases per VM; 6,000 stratified bootstrap resamples. The unassigned wall-time remainder is an arithmetic timer residual, not a measured causal overhead term.

The post-hoc bootstrap analyses use fixed RNG seeds and are conditional on the retained observation/prediction arrays; they cannot identify unobserved future labels, closed-loop behavior of hypothetical policies, or the causes of wall-time differences.

The output files in this directory were generated from the canonical unmodified original ZIP. Original results are not overwritten or replaced; new tables in Online Resource 1 are clearly labeled post hoc.
