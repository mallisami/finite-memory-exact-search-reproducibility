#!/usr/bin/env python3
"""Post-hoc PCR2 retained-evidence diagnostics. No model refit and no source data modification.
Inputs: unchanged original 2026-11-08 evidence archive. Outputs: JSON + CSV for independently reproducible sensitivity/decomposition.
Requires: numpy, pandas, scikit-learn. Deterministic bootstraps by seed.
"""
from pathlib import Path
from zipfile import ZipFile
import json,io,hashlib
import numpy as np
import pandas as pd
from sklearn.metrics import average_precision_score, roc_auc_score, brier_score_loss

BASE=Path(__file__).resolve().parent
DEFAULT=BASE.parent/'02_IMMUTABLE_EVIDENCE_20261108.zip'
import argparse
ap=argparse.ArgumentParser();ap.add_argument('--archive',type=Path,default=DEFAULT);ap.add_argument('--out',type=Path,default=BASE/'outputs');args=ap.parse_args()
args.out.mkdir(parents=True,exist_ok=True)
ARCH_EXPECTED='c7537adde1b38d2880f0cc8505b87d0a21df08bcc58cf24de27b74378533a8e5'
with args.archive.open('rb') as f:
 h=hashlib.file_digest(f,'sha256').hexdigest()
if h!=ARCH_EXPECTED:raise SystemExit('Archive content hash mismatch; analysis stopped: '+h)
z=ZipFile(args.archive)
paths=z.namelist()

def get(suffix):
 matches=[x for x in paths if x.endswith(suffix)]
 if len(matches)!=1:raise RuntimeError(f'{suffix}: expected exactly 1 match, found {len(matches)}')
 return z.read(matches[0]),matches[0]
def df(suffix):
 b,path=get(suffix);return pd.read_csv(io.BytesIO(b)),path,hashlib.sha256(b).hexdigest()

train,trainpath,trainhash=df('01_Development_Model/marginal_work_training.csv')
oof,oofpath,oofhash=df('step4_outputs/oof_predictions.csv')
assert trainhash=='310795883e92467f411fc8387b9c740bb8bc6e46efcbad6ac14a780547147cb5'
assert len(train)==len(oof)==1948
assert (train[['seed','created_iteration','positive','saving_nodes','event']].reset_index(drop=True).astype(str)==oof[['seed','created_iteration','positive','saving_nodes','event']].reset_index(drop=True).astype(str)).all().all()
late=(train.created_iteration>160)&(train.event=='none')
assert late.sum()==121 and train.event.eq('none').sum()==311 and train.positive.sum()==73
eligible=~late
prob=oof.oof_probability_nested_platt.to_numpy(float)
rawprob=oof.oof_probability_class_balanced.to_numpy(float)
y=train.positive.to_numpy(int)

def met(indices,p=prob):
 yy=y[indices];pp=p[indices]
 return {'n':int(len(yy)),'positive':int(yy.sum()),'prevalence':float(yy.mean()),'auroc':float(roc_auc_score(yy,pp)) if 0<yy.sum()<len(yy) else None,'average_precision':float(average_precision_score(yy,pp)) if yy.sum() else None,'brier':float(brier_score_loss(yy,pp)),'mean_probability':float(pp.mean()),'constant_prevalence_brier':float(yy.mean()*(1-yy.mean()))}
idx_all=np.arange(len(train));idx_excl=np.flatnonzero(eligible.to_numpy())
metrics={'all':met(idx_all),'exclude_late_none':met(idx_excl),'all_raw_uncalibrated':met(idx_all,rawprob),'exclude_late_none_raw_uncalibrated':met(idx_excl,rawprob)}
# Cluster-resampled, same fitted OOF predictions; these intervals are diagnostic not a validated new predictor.
seeds=train.seed.unique();ix_by_seed={v:np.flatnonzero(train.seed.to_numpy()==v) for v in seeds}
rng=np.random.default_rng(20261110);boot=[]
for _ in range(3000):
 chosen=rng.choice(seeds,len(seeds),replace=True)
 ix=np.concatenate([ix_by_seed[x] for x in chosen]);ix2=ix[~late.to_numpy()[ix]]
 if len(np.unique(y[ix]))<2 or len(np.unique(y[ix2]))<2:continue
 a=met(ix);b=met(ix2)
 boot.append({'delta_AP_exclude_minus_all':b['average_precision']-a['average_precision'],'delta_Brier_exclude_minus_all':b['brier']-a['brier'],'delta_AUROC_exclude_minus_all':b['auroc']-a['auroc']})
bootci={key:{'point':metrics['exclude_late_none'][{'delta_AP_exclude_minus_all':'average_precision','delta_Brier_exclude_minus_all':'brier','delta_AUROC_exclude_minus_all':'auroc'}[key]]-metrics['all'][{'delta_AP_exclude_minus_all':'average_precision','delta_Brier_exclude_minus_all':'brier','delta_AUROC_exclude_minus_all':'auroc'}[key]],'ci95':list(np.quantile([x[key] for x in boot],[.025,.975])),'replicates_valid':len(boot)} for key in boot[0]}
seed=train.groupby('seed',sort=False).agg(n=('positive','size'),positive=('positive','sum'),total_saved_nodes=('saving_nodes','sum'),none=('event',lambda a:int((a=='none').sum())),late_none=('created_iteration',lambda a:0)).reset_index(); seed['late_none']=train[late].groupby('seed').size().reindex(seed.seed,fill_value=0).to_numpy();seed.to_csv(args.out/'RQ3_SEED_HETEROGENEITY.csv',index=False)
print('censor',metrics,'boot',bootci)
# Conditional magnitude OOF: train-fold positive median is fit on outer TRAIN ONLY.
condpred=oof.oof_conditional_magnitude_nodes.to_numpy(float)
valid=y==1
pred_med=np.empty(len(train));pred_med[:]=np.nan
for fold in oof.outer_fold.unique():
 ref=train.loc[(oof.outer_fold!=fold)&(train.positive==1),'saving_nodes'];assert len(ref)>0
 pred_med[oof.outer_fold==fold]=ref.median()
mae_cond=float(np.abs(condpred[valid]-train.saving_nodes.to_numpy(float)[valid]).mean())
mae_med=float(np.abs(pred_med[valid]-train.saving_nodes.to_numpy(float)[valid]).mean())
mag={'n_positive':int(valid.sum()),'oof_conditional_ridge_mae_nodes':mae_cond,'outer_training_positive_median_mae_nodes':mae_med,'relative_mae':mae_cond/mae_med}
# Bootstrap grouped at seed for difference in MAE, no new training.
rng=np.random.default_rng(20261111);diffs=[]
for _ in range(3000):
 sampled=rng.choice(seeds,len(seeds),replace=True)
 ix=np.concatenate([ix_by_seed[x] for x in sampled]); ix=ix[y[ix]==1]
 if len(ix)==0:continue
 diffs.append(np.abs(condpred[ix]-train.saving_nodes.to_numpy(float)[ix]).mean()-np.abs(pred_med[ix]-train.saving_nodes.to_numpy(float)[ix]).mean())
mag['paired_mae_excess_nodes']=mae_cond-mae_med;mag['paired_mae_excess_bootstrap_ci95']=list(np.quantile(diffs,[.025,.975]));mag['bootstrap_replicates']=len(diffs)
seedpositive=seed[seed.positive>0].sort_values('total_saved_nodes',ascending=False)
mag.update({'seed_groups':int(len(seed)),'positive_seed_groups':int(len(seedpositive)),'positive_share':float(y.mean()),'top_three_seed_saving_share':float(seedpositive.total_saved_nodes.head(3).sum()/seed.total_saved_nodes.sum()),'saved_nodes_total':float(seed.total_saved_nodes.sum()),'positive_seed_positive_counts':seedpositive.positive.tolist()})
print('magnitude',mag)
# Graph P7: original matched rows, 25% memory budget, explicitly component-sum not full wall time.
p7,p7path,p7hash=df('AWS_P7_P8/03_QUICK_ACCESS_RESULTS/P7/p7_confirmatory_runs.csv')
p7=p7[(p7.budget_fraction==0.25)&p7.policy.isin(['learned','empirical_compatible'])].copy()
assert p7.groupby('policy').size().to_dict()=={'learned':45,'empirical_compatible':45}
keys=['domain','instance_seed'];gcols=['serialization_ms','restoration_ms','selection_ms','objective_signature_ms','history_feature_ms','model_scoring_ms']
p7['timed_component_sum_ms']=p7[gcols].sum(axis=1)
p7['feature_plus_scoring_ms']=p7[['history_feature_ms','model_scoring_ms']].sum(axis=1)
paired=p7.pivot(index=keys,columns='policy',values=gcols+['timed_component_sum_ms','feature_plus_scoring_ms','branch_pops_executed']).dropna()
assert len(paired)==45
p7diff=paired.xs('learned',level='policy',axis=1)-paired.xs('empirical_compatible',level='policy',axis=1)
rng=np.random.default_rng(20261112)
p7boot=np.array([np.mean(rng.choice(p7diff.timed_component_sum_ms.to_numpy(),45,replace=True)) for _ in range(6000)])
p7report={'n_matched_cases':45,'learned_mean_component_ms':float(paired['timed_component_sum_ms']['learned'].mean()),'empirical_mean_component_ms':float(paired['timed_component_sum_ms']['empirical_compatible'].mean()),'paired_delta_mean_ms':float(p7diff.timed_component_sum_ms.mean()),'paired_delta_ci95':list(np.quantile(p7boot,[.025,.975])),'learned_mean_scoring_plus_feature_ms':float(paired['feature_plus_scoring_ms']['learned'].mean()),'mean_policy_component_differences_ms':{k:float(v) for k,v in p7diff[gcols].mean().items()},'new_pop_ties':int((p7diff.branch_pops_executed==0).sum()),'component_sum_is_not_total_controller_wall':True}
p7.reset_index(drop=True).to_csv(args.out/'P7_COMPONENT_INPUT_SELECTED.csv',index=False)
print('P7',p7report)
# MDKP timed panel: within case median across five runs, matched across three policies, stratified VM bootstrap
vm,vmpath,vmhash=df('MDKP_VM90_RESULTS/outputs/MERGED_RAW.csv')
assert len(vm)==1350 and set(vm.policy)=={'direct_utility','empirical_pW','restart'}
mc=['wall_ms','repair_search_ms','model_scoring_ms','selection_ms','serialization_ms','restoration_ms','branches','useful_resumes']
vm['unattributed_wall_remainder_ms']=vm.wall_ms-vm[['repair_search_ms','model_scoring_ms','selection_ms','serialization_ms','restoration_ms']].sum(axis=1)
mc.append('unattributed_wall_remainder_ms')
case=vm.groupby(['vm_id','global_case_index','policy'],as_index=False)[mc].median()
assert len(case)==270
wide=case.pivot(index=['vm_id','global_case_index'],columns='policy',values=mc)
assert len(wide)==90
vmdiff=wide.xs('direct_utility',level='policy',axis=1)-wide.xs('empirical_pW',level='policy',axis=1)
vmdiff.reset_index().to_csv(args.out/'MDKP_VM90_PAIRED_MEDIAN_COMPONENT_DIFFERENCES.csv',index=False)
case.to_csv(args.out/'MDKP_VM90_CASE_POLICY_MEDIAN_COMPONENTS.csv',index=False)
vmgroups=np.array(wide.index.get_level_values('vm_id'))
rng=np.random.default_rng(20261113);bmean=[];blog=[]
vd_np=vmdiff.to_numpy(dtype=float)
rl_np=np.log((wide.wall_ms.direct_utility/wide.wall_ms.empirical_pW).to_numpy(dtype=float))
for _ in range(6000):
 pick=np.concatenate([rng.choice(np.flatnonzero(vmgroups==vm_name),30,replace=True) for vm_name in np.unique(vmgroups)])
 bmean.append(vd_np[pick].mean(axis=0))
 blog.append(rl_np[pick].mean())
bmean=np.asarray(bmean)
wallratio=float(np.exp(np.log(wide.wall_ms.direct_utility/wide.wall_ms.empirical_pW).mean()))
vmreport={'n_cases':len(wide),'repetitions':5,'vm_groups':{v:int((vmgroups==v).sum()) for v in np.unique(vmgroups)},'component_case_median_then_mean_ms':{pol:{k:float(wide[k][pol].mean()) for k in mc} for pol in ['direct_utility','empirical_pW','restart']},'paired_direct_minus_empirical_mean_ms':{k:float(vmdiff[k].mean()) for k in mc},'paired_component_difference_vm_stratified_ci95_ms':{k:list(np.quantile(bmean[:,i],[.025,.975])) for i,k in enumerate(mc)},'geometric_wall_time_ratio_direct_over_empirical':wallratio,'vm_stratified_bootstrap_ratio_ci95':list(np.exp(np.quantile(blog,[.025,.975]))),'five_components_plus_remainder_are_observed_timers_not_causal_factors':True}
print('VM',{'ratio':wallratio,'means':vmreport['paired_direct_minus_empirical_mean_ms']})
# source hash provenance + block pre-existing retrospective results (different 1,875 reconstructed population)
old,oldpath=get('PCR2_RQ3_CENSOR_QUALITY_OOF_20261106/RESULT_SUMMARY.json');oldhash=hashlib.sha256(old).hexdigest()
oldsummary=json.loads(old)
result={'analysis_release':'PCR2-P0-DIAGNOSTICS-20261110-R3','scope':'post-hoc nonconfirmatory; no model fitting, no changed labels, no AWS rerun','sources':{'original_author_zip':h,'training_csv':{'path':trainpath,'sha256':trainhash},'oof_predictions':{'path':oofpath,'sha256':oofhash},'p7_controller_rows':{'path':p7path,'sha256':p7hash},'mdkp_vm90_raw':{'path':vmpath,'sha256':vmhash},'earlier_reconstructed_censor_study':{'path':oldpath,'sha256':oldhash,'n_input_rows':oldsummary['counts']['input_rows'],'decision':oldsummary['decision']}},'censoring':{'late_none_count':int(late.sum()),'none_count':int((train.event=='none').sum()),'affected_seeds':int(train.loc[late,'seed'].nunique()),'total_n':len(train),'nominal_horizon':40,'last_iteration':200,'mask':'created_iteration>160 and event==none','OOF_metrics_same_original_predictions':metrics,'seed_cluster_bootstrap_delta_metrics':bootci,'disclaimer':'Exclusion of administratively short-observed negatives changes evaluation population; same OOF predictions were trained under original labels; not corrected model performance, no identification of unobserved future.'},'mdkp_failure':mag,'p7_graph_component_cost':p7report,'mdkp_vm90_timing_components':vmreport,'guardrails':['P7 component timers are not full controller wall time.','P7 and P0/VM90 are different protocols and cannot be subtracted causally.','MDKP wall decomposition includes unattributed remainder and changes in policy trajectories.','Out-of-fold predictions use replacement seed-group folds, not recovered original official folds.','Previous 1,875-row censor/quality diagnostic is a different reconstructed sample and was NO-GO.','No improved model or net runtime advantage is claimed.']}
(args.out/'PCR2_P0_DIAGNOSTICS.json').write_text(json.dumps(result,indent=2)+'\n')
(args.out/'SOURCE_HASHES.json').write_text(json.dumps(result['sources'],indent=2)+'\n')
print('DONE',args.out)
