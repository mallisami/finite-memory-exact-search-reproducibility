# PCR2 offline reproducibility analysis update (public research-only)

**Scope:** Source-derived analysis reports, sensitivity tables, reproducibility scripts, and provenance notes from the November 10 R6 editorial research release. This is **not a manuscript or paper package**. No paper PDF, Online Resource, LaTeX, bibliographic or source figure artwork, author metadata, private host receipts, or original historical ZIP is included.

The existing GitHub repository already holds the frozen original computational implementation, 2026-11-07 corrected AWS P8, nested P9 and P10 results, RQ2 three-arm data, the graph and MDKP timing rows, comparator data and tests. This update does not duplicate those existing source data or the 24 module historical source snapshot.

**Data restrictions:** These files are post hoc diagnostic outputs or bounded source-audit records. They are NOT a new experiment, confirmation, retrained classifier, causal overhead attribution, improved policy runtime result, or production deployment. The RQ3 original training set has 1,948 rows and 121 late no-recurrence rows; the separate reconstructed 1,875-row population has 117 censored candidates and must not be pooled. P7 45 cases tie on branch pops. The MDKP 90-case matched timing is a distinct protocol. The original RQ3 label producer was not recovered. Historical Path A/B NO-GO conclusions are preserved.

**Rerun boundary:** Some unchanged analysis scripts require the separate private 2026-11-08 authoritative original evidence ZIP as input and will *not* run from this GitHub snapshot alone. This public package retains the source-derived output receipts, hashes and methods for independent audit without publishing the author-side historical archive. There is no DOI and no claim of independent reconstruction of deleted cloud hosts.

**Integrity:** `FILE_SHA256.csv` records hashes of every included research file; `FILE_SHA256.csv` excludes itself and this README. No original results were overwritten. Original files were preserved byte-for-byte inside this research-only ZIP.

**Primary starting points:** `09_POSTHOC_P0_DIAGNOSTICS_20261110/README.md`, `09_POSTHOC_P0_DIAGNOSTICS_20261110/PCR2_P0_DIAGNOSTICS.json`, `10_OFFLINE_COMPARATOR_AND_RQ3_RECOVERY/INDEPENDENT_COMPARATOR_DECISION.md`, `10_OFFLINE_COMPARATOR_AND_RQ3_RECOVERY/EXTERNAL_COMPARATOR_RETAINED_DATA_AUDIT.json`, `10_OFFLINE_COMPARATOR_AND_RQ3_RECOVERY/FROZEN_CASE_SPOT_CHECKS.json`.
