#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
source .venv/bin/activate 2>/dev/null || true
python scripts/merge_analyze.py | tee outputs/final_analysis_console.txt
