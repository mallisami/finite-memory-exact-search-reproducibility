"""PCR Transactions MDKP Backend Extension Engine.

Implements the five-policy comparative evaluation:
1. restart
2. empirical_pW
3. learned_pW (PCR-v1 baseline)
4. empirical_pC
5. learned_pC
Plus keep_all for upper-resource reference.

Features:
- Deterministic 6 operation counters tracked strictly in sidecars.
- Scientific checkpoint blobs (MDKPCheckpoint) remain 100% byte-for-byte identical
  to baseline PCR-v1.
- Knapsack allocation via select_exact_expected_value using exact scientific bytes.
- Trajectory hashing (SHA-256) over full iteration history.
- High-resolution timing (perf_counter_ns / process_time_ns) with buffered logging.
"""
from __future__ import annotations

from dataclasses import dataclass, field
import hashlib
import math
import pickle
import time
from typing import Literal, Mapping, Sequence
import numpy as np

from .allocation import ValueItem, select_exact_expected_value
from .core import (
    MDKPCheckpoint,
    MDKPInstance,
    SearchNode,
    _context_order,
    _incumbent_bits,
    _upper_bound,
    checkpoint_compatible,
    checkpoint_solution,
    feasible,
    initial_solution,
    initialize_checkpoint,
    make_context_library,
    make_context_trace,
    make_instance,
    objective_cost,
    residual_capacity,
)
from .controller import (
    CompatStats,
    HistoryRow,
    P10Predictor,
    _feature_row,
    _history_recurrence_prob,
    _invalidate_incompatible,
)

try:
    from .compute_counters import ComputeCounters, COUNTER_NAMES
except (ImportError, ValueError):
    from compute_counters import ComputeCounters, COUNTER_NAMES

MDKPPolicyName = Literal["restart", "empirical_pW", "learned_pW", "empirical_pC", "learned_pC", "keep_all"]


def advance_checkpoint_with_counters(
    instance: MDKPInstance,
    cp: MDKPCheckpoint,
    budget_nodes: int,
    counters: ComputeCounters,
) -> tuple[int, int, int, bool]:
    """Advance a serializable DFS B&B checkpoint by at most budget_nodes, recording the 6 operation counters."""
    if cp.instance_fingerprint != instance.fingerprint:
        raise ValueError("instance mismatch")
    expanded = 0
    while cp.frontier and expanded < int(budget_nodes):
        node = cp.frontier.pop()
        expanded += 1
        cp.invested_nodes += 1
        counters.expanded_nodes += 1

        ub = _upper_bound(instance, cp, node)
        counters.bound_evals += 1
        counters.incumbent_evals += 1
        if ub <= cp.best_profit + 1e-12:
            continue

        if node.pos >= len(cp.order):
            counters.incumbent_evals += 1
            if node.profit > cp.best_profit:
                cp.best_profit = int(node.profit)
                cp.best_bits = int(node.bits)
            continue

        pos = node.pos
        item = cp.order[pos]
        rem = np.asarray(node.remaining, dtype=np.int64)

        # Exclude branch first on stack so include branch is explored first (LIFO).
        cp.frontier.append(
            SearchNode(pos + 1, tuple(int(v) for v in rem), int(node.profit), int(node.bits))
        )
        counters.generated_children += 1
        counters.frontier_inserts += 1

        wi = instance.weights[:, item]
        counters.feasibility_checks += 1
        if np.all(wi <= rem):
            rem2 = rem - wi
            cp.frontier.append(
                SearchNode(
                    pos + 1,
                    tuple(int(v) for v in rem2),
                    int(node.profit + instance.profits[item]),
                    int(node.bits | (1 << pos)),
                )
            )
            counters.generated_children += 1
            counters.frontier_inserts += 1

    cp.exact = not cp.frontier
    return int(cp.best_bits), int(cp.best_profit), int(expanded), bool(cp.exact)


def advance_checkpoint_gap_target(
    instance: MDKPInstance,
    cp: MDKPCheckpoint,
    max_nodes: int,
    counters: ComputeCounters,
    ub_stack: list[float],
    gap_target: float,
    check_interval: int = 16,
) -> tuple[int, int, int, bool, bool]:
    """V5 work-saving slice: advance until the relative bound gap is <= gap_target or max_nodes pops.

    ``ub_stack`` is a controller-side sidecar list aligned index-for-index with
    ``cp.frontier``: entry i is a valid upper bound on the profit reachable from
    frontier node i (its parent's bound; +inf for the untouched root). Children of a
    node inherit the bound computed when that node was popped, so no additional
    bound evaluations are performed and the six scientific counters are unchanged
    in meaning. The scientific checkpoint blob is untouched (the sidecar is never
    serialized into it), preserving the PCR-v1 byte contract.

    Returns (best_bits, best_profit, expanded, exact, within_target).
    """
    if cp.instance_fingerprint != instance.fingerprint:
        raise ValueError("instance mismatch")
    if len(ub_stack) != len(cp.frontier):
        raise ValueError("ub_stack is not aligned with the checkpoint frontier")
    expanded = 0
    within = False
    interval = max(1, int(check_interval))
    while cp.frontier and expanded < int(max_nodes):
        if expanded % interval == 0:
            frontier_ub = max(ub_stack)
            if frontier_ub != math.inf:
                gap = (frontier_ub - cp.best_profit) / max(abs(float(cp.best_profit)), 1.0)
                if gap <= float(gap_target):
                    within = True
                    break
        node = cp.frontier.pop()
        ub_stack.pop()
        expanded += 1
        cp.invested_nodes += 1
        counters.expanded_nodes += 1

        ub = _upper_bound(instance, cp, node)
        counters.bound_evals += 1
        counters.incumbent_evals += 1
        if ub <= cp.best_profit + 1e-12:
            continue

        if node.pos >= len(cp.order):
            counters.incumbent_evals += 1
            if node.profit > cp.best_profit:
                cp.best_profit = int(node.profit)
                cp.best_bits = int(node.bits)
            continue

        pos = node.pos
        item = cp.order[pos]
        rem = np.asarray(node.remaining, dtype=np.int64)

        cp.frontier.append(
            SearchNode(pos + 1, tuple(int(v) for v in rem), int(node.profit), int(node.bits))
        )
        ub_stack.append(float(ub))
        counters.generated_children += 1
        counters.frontier_inserts += 1

        wi = instance.weights[:, item]
        counters.feasibility_checks += 1
        if np.all(wi <= rem):
            rem2 = rem - wi
            cp.frontier.append(
                SearchNode(
                    pos + 1,
                    tuple(int(v) for v in rem2),
                    int(node.profit + instance.profits[item]),
                    int(node.bits | (1 << pos)),
                )
            )
            ub_stack.append(float(ub))
            counters.generated_children += 1
            counters.frontier_inserts += 1

    cp.exact = not cp.frontier
    if cp.frontier and not within:
        # Final check so a slice that reached the target exactly on its last pop retires.
        frontier_ub = max(ub_stack)
        if frontier_ub != math.inf:
            gap = (frontier_ub - cp.best_profit) / max(abs(float(cp.best_profit)), 1.0)
            within = gap <= float(gap_target)
    return int(cp.best_bits), int(cp.best_profit), int(expanded), bool(cp.exact), bool(within)


@dataclass
class StoredMDKPSidecar:
    key: tuple[int, ...]
    blob: bytes
    size_bytes: int
    expected_value: float
    cumulative_nodes: int
    created_iteration: int
    compute_counters: ComputeCounters = field(default_factory=ComputeCounters)
    # V5 gap-target mode needs a resumable frontier-bound sidecar. It is stored
    # separately from the scientific checkpoint blob so V4 fixed-mode bytes are
    # unchanged, but its serialized bytes are included in V5 capacity accounting.
    frontier_ub_blob: bytes | None = None
    auxiliary_size_bytes: int = 0


@dataclass
class MDKPExecutionResult:
    seed: int
    n_items: int
    n_dims: int
    destroy_size: int
    slice_nodes: int
    iterations: int
    context_count: int
    policy: str
    budget_bytes: int | None
    initial_cost: float
    final_cost: float
    best_cost: float
    branch_nodes_executed: int
    useful_resumes: int
    reused_prior_nodes: int
    checkpoint_creations: int
    capacity_evictions: int
    invalidation_evictions: int
    peak_checkpoint_bytes: int
    byte_time: int
    peak_live_checkpoints: int
    fraction_iterations_live_ge4: float
    mean_checkpoint_size_bytes: float
    max_checkpoint_size_bytes: int
    serialization_ms: float
    restoration_ms: float
    selection_ms: float
    model_scoring_ms: float
    repair_search_ms: float
    accepted_moves: int
    trajectory_hash: str
    end_to_end_wall_ns: int
    end_to_end_cpu_ns: int
    total_counters: dict[str, int]
    # --- V5 extension fields (defaults reproduce the V4 semantics) ---
    slice_mode: str = "fixed"
    gap_target: float = 0.0
    slice_cap: int | None = None
    epsilon_retirements: int = 0
    exact_retirements: int = 0
    lazy_features: bool = False

    def to_dict(self) -> dict[str, object]:
        d = dict(self.__dict__)
        d["end_to_end_wall_ms"] = float(self.end_to_end_wall_ns / 1e6)
        d["end_to_end_cpu_ms"] = float(self.end_to_end_cpu_ns / 1e6)
        return d


def run_mdkp_campaign_case(
    *,
    seed: int,
    n_items: int = 168,
    destroy_size: int = 54,
    slice_nodes: int = 384,
    iterations: int = 200,
    policy: MDKPPolicyName,
    context_count: int = 18,
    budget_bytes: int | None = 4206,
    predictor: P10Predictor | None = None,
    compute_weights: Mapping[str, int | float] | None = None,
    n_dims: int = 3,
    future_horizon: int = 40,
    slice_mode: Literal["fixed", "gap_target"] = "fixed",
    gap_target: float = 0.0,
    slice_cap: int | None = None,
    gap_check_interval: int = 16,
    lazy_features: bool = False,
) -> MDKPExecutionResult:
    """Run one complete timed MDKP case with high-resolution timer and deterministic trace.

    V5 options (all default to V4 behaviour):
      slice_mode="fixed":      every repair call pops exactly ``slice_nodes`` (unless exhausted).
      slice_mode="gap_target": every repair call pops until relative bound gap <= gap_target
                               or ``slice_cap`` pops; a resumed checkpoint needs fewer pops.
      lazy_features:           compute the P10 feature row only for learned policies. In V4 the
                               feature row was computed for every policy, including restart, so
                               the MDKP restart baseline paid the learned policy's feature cost
                               while the graph restart baseline did not.
    """
    weights_dict = dict(compute_weights) if compute_weights else {k: 1 for k in COUNTER_NAMES}
    if slice_mode not in ("fixed", "gap_target"):
        raise ValueError(f"unknown slice_mode {slice_mode!r}")
    cap = int(slice_cap) if slice_cap is not None else int(slice_nodes)
    learned = policy in ("learned_pW", "learned_pC")
    exact_retirements = 0
    epsilon_retirements = 0

    instance = make_instance(n_items, seed, n_dims=n_dims)
    x = initial_solution(instance)
    init_cost = objective_cost(instance, x)
    best_cost = init_cost
    contexts = make_context_library(n_items, destroy_size, seed, count=context_count)
    trace = make_context_trace(contexts, iterations, seed)

    history: list[HistoryRow] = []
    records: dict[tuple[int, ...], StoredMDKPSidecar] = {}
    compat: dict[tuple[int, ...], CompatStats] = {}
    global_compat = CompatStats()

    branch_nodes = 0
    useful_resumes = 0
    reused_prior = 0
    creations = 0
    cap_evict = 0
    invalid_evict = 0
    serialization_ms = restoration_ms = selection_ms = scoring_ms = repair_ms = 0.0
    peak_bytes = 0
    byte_time = 0
    peak_live = 0
    live_ge4 = 0
    checkpoint_sizes: list[int] = []
    accepted_moves = 0
    total_counters = ComputeCounters()

    traj_hasher = hashlib.sha256()

    t_wall_start = time.perf_counter_ns()
    t_cpu_start = time.process_time_ns()

    for t, (ctx, ctx_class, u_accept) in enumerate(trace, 1):
        before = objective_cost(instance, x)
        temp = max(1e-9, 0.02 * abs(init_cost) * (0.995 ** (t - 1)))
        feats = None
        if learned or not lazy_features:
            feats = _feature_row(history, t, ctx, ctx_class, before, best_cost, temp, init_cost)

        record = records.get(ctx)
        cp = None
        resumed = False
        reused = 0
        cp_counters = ComputeCounters()
        ub_stack: list[float] = [math.inf]

        if policy != "restart" and record is not None:
            tt = time.perf_counter()
            cand = pickle.loads(record.blob)
            restoration_ms += (time.perf_counter() - tt) * 1000.0
            if checkpoint_compatible(instance, x, cand):
                cp = cand
                resumed = True
                reused = int(record.cumulative_nodes)
                useful_resumes += 1
                reused_prior += reused
                cp_counters = record.compute_counters.copy()
                if record.frontier_ub_blob is not None:
                    tt = time.perf_counter()
                    ub_stack = list(pickle.loads(record.frontier_ub_blob))
                    restoration_ms += (time.perf_counter() - tt) * 1000.0
                s = compat.setdefault(ctx, CompatStats())
                s.compatible += 1
                global_compat.compatible += 1
            else:
                records.pop(ctx, None)
                invalid_evict += 1
                s = compat.setdefault(ctx, CompatStats())
                s.incompatible += 1
                global_compat.incompatible += 1

        if cp is None:
            cp = initialize_checkpoint(instance, x, ctx)
            creations += 1
            cp_counters = ComputeCounters(incumbent_evals=1, frontier_inserts=1)

        step_counters = ComputeCounters()
        tt = time.perf_counter()
        if slice_mode == "fixed":
            _, _, expanded, exact = advance_checkpoint_with_counters(instance, cp, slice_nodes, step_counters)
            within_target = False
        else:
            _, _, expanded, exact, within_target = advance_checkpoint_gap_target(
                instance, cp, cap, step_counters, ub_stack, gap_target, gap_check_interval
            )
        repair_ms += (time.perf_counter() - tt) * 1000.0
        branch_nodes += int(expanded)
        if exact:
            exact_retirements += 1
        elif within_target:
            epsilon_retirements += 1
        retired = exact or within_target

        cp_counters = cp_counters.add(step_counters)
        total_counters = total_counters.add(step_counters)
        if not resumed:
            total_counters.incumbent_evals += 1
            total_counters.frontier_inserts += 1

        proposal = checkpoint_solution(instance, x, cp)
        after_prop = objective_cost(instance, proposal)
        delta = after_prop - before
        accept = (delta <= 0) or (u_accept < math.exp(-max(delta, 0.0) / temp))

        if accept:
            moved = tuple(np.flatnonzero(proposal != x).astype(int).tolist())
            x = proposal
            accepted_moves += 1
            if objective_cost(instance, x) < best_cost:
                best_cost = objective_cost(instance, x)
        else:
            moved = ()

        if policy != "restart" and not retired:
            if policy == "keep_all":
                p = 1.0
                val = 1.0
            elif policy in ("empirical_pW", "empirical_pC"):
                p_rec = _history_recurrence_prob(history, t, ctx, future_horizon)
                s = compat.setdefault(ctx, CompatStats())
                p = float(np.clip(p_rec * s.prob(global_compat), 1e-6, 1 - 1e-6))
                if policy == "empirical_pW":
                    val = float(p * cp.invested_nodes)
                else:
                    c_val = cp_counters.compute_value(weights_dict)
                    val = float(p * c_val)
            elif policy in ("learned_pW", "learned_pC"):
                if predictor is None:
                    raise ValueError("learned policy needs P10 predictor")
                tt = time.perf_counter()
                p = predictor.predict(feats)
                scoring_ms += (time.perf_counter() - tt) * 1000.0
                if policy == "learned_pW":
                    val = float(p * cp.invested_nodes)
                else:
                    c_val = cp_counters.compute_value(weights_dict)
                    val = float(p * c_val)
            else:
                raise AssertionError(f"Unknown policy: {policy}")

            tt = time.perf_counter()
            blob = pickle.dumps(cp, protocol=pickle.HIGHEST_PROTOCOL)
            ub_blob = (
                pickle.dumps(tuple(float(v) for v in ub_stack), protocol=pickle.HIGHEST_PROTOCOL)
                if slice_mode == "gap_target" else None
            )
            serialization_ms += (time.perf_counter() - tt) * 1000.0
            aux_size = len(ub_blob) if ub_blob is not None else 0
            size = len(blob) + aux_size
            checkpoint_sizes.append(size)

            incoming = StoredMDKPSidecar(
                key=ctx,
                blob=blob,
                size_bytes=size,
                expected_value=float(val),
                cumulative_nodes=int(cp.invested_nodes),
                created_iteration=t,
                compute_counters=cp_counters,
                frontier_ub_blob=ub_blob,
                auxiliary_size_bytes=int(aux_size),
            )

            # Knapsack selection
            if policy == "keep_all":
                records[incoming.key] = incoming
            else:
                assert budget_bytes is not None
                cand_map = dict(records)
                cand_map[incoming.key] = incoming
                items = [ValueItem(k, v.size_bytes, v.expected_value) for k, v in cand_map.items()]
                t_sel = time.perf_counter()
                keep = set(select_exact_expected_value(items, budget_bytes=int(budget_bytes)))
                selection_ms += (time.perf_counter() - t_sel) * 1000.0
                evicted = len(set(records) - keep)
                cap_evict += evicted
                records = {k: v for k, v in cand_map.items() if k in keep}
        else:
            records.pop(ctx, None)

        if accept and moved:
            # Checkpoint invalidation
            bad = []
            for k, r in list(records.items()):
                try:
                    c_obj = pickle.loads(r.blob)
                except Exception:
                    bad.append(k)
                    continue
                if not checkpoint_compatible(instance, x, c_obj):
                    bad.append(k)
            for k in bad:
                records.pop(k, None)
            invalid_evict += len(bad)

        bytes_now = sum(r.size_bytes for r in records.values())
        peak_bytes = max(peak_bytes, bytes_now)
        byte_time += bytes_now
        peak_live = max(peak_live, len(records))
        live_ge4 += int(len(records) >= 4)

        after = objective_cost(instance, x)
        history.append(HistoryRow(t, ctx, ctx_class, bool(accept), moved, float(before), float(after)))

        # Update trajectory hash
        traj_hasher.update(f"{t}:{int(accept)}:{after:.6f}:".encode())
        traj_hasher.update(x.tobytes())

    t_wall_end = time.perf_counter_ns()
    t_cpu_end = time.process_time_ns()

    return MDKPExecutionResult(
        seed=int(seed),
        n_items=int(n_items),
        n_dims=int(n_dims),
        destroy_size=int(destroy_size),
        slice_nodes=int(slice_nodes),
        iterations=int(iterations),
        context_count=int(context_count),
        policy=str(policy),
        budget_bytes=None if budget_bytes is None else int(budget_bytes),
        initial_cost=float(init_cost),
        final_cost=float(objective_cost(instance, x)),
        best_cost=float(best_cost),
        branch_nodes_executed=int(branch_nodes),
        useful_resumes=int(useful_resumes),
        reused_prior_nodes=int(reused_prior),
        checkpoint_creations=int(creations),
        capacity_evictions=int(cap_evict),
        invalidation_evictions=int(invalid_evict),
        peak_checkpoint_bytes=int(peak_bytes),
        byte_time=int(byte_time),
        peak_live_checkpoints=int(peak_live),
        fraction_iterations_live_ge4=float(live_ge4 / max(iterations, 1)),
        mean_checkpoint_size_bytes=float(np.mean(checkpoint_sizes)) if checkpoint_sizes else 0.0,
        max_checkpoint_size_bytes=int(max(checkpoint_sizes) if checkpoint_sizes else 0),
        serialization_ms=float(serialization_ms),
        restoration_ms=float(restoration_ms),
        selection_ms=float(selection_ms),
        model_scoring_ms=float(scoring_ms),
        repair_search_ms=float(repair_ms),
        accepted_moves=int(accepted_moves),
        trajectory_hash=traj_hasher.hexdigest(),
        end_to_end_wall_ns=int(t_wall_end - t_wall_start),
        end_to_end_cpu_ns=int(t_cpu_end - t_cpu_start),
        total_counters=total_counters.to_dict(),
        slice_mode=str(slice_mode),
        gap_target=float(gap_target),
        slice_cap=cap,
        epsilon_retirements=int(epsilon_retirements),
        exact_retirements=int(exact_retirements),
        lazy_features=bool(lazy_features),
    )
