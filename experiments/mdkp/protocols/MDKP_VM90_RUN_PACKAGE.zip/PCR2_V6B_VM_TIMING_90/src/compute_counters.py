"""Deterministic exact-search operation counters and compute-value sidecars.

Frozen specification for PCR Transactions extension:
Six fixed deterministic operation counters:
1. expanded_nodes: number of branch-and-bound nodes popped and expanded
2. bound_evals: number of upper/lower bound function evaluations
3. generated_children: number of child branches generated
4. feasibility_checks: number of feasibility/capacity tests executed
5. incumbent_evals: number of candidate/leaf objective comparisons against best incumbent
6. frontier_inserts: number of unpruned branches inserted into the frontier/priority queue

Counters are integer, non-negative, branch-safe, and monotone across resumption.
They are stored exclusively in controller-side sidecar metadata and NEVER serialized
into the scientific solver-state blob.
"""
from __future__ import annotations
from dataclasses import dataclass, asdict
from typing import Mapping, Sequence

COUNTER_NAMES: tuple[str, ...] = (
    "expanded_nodes",
    "bound_evals",
    "generated_children",
    "feasibility_checks",
    "incumbent_evals",
    "frontier_inserts",
)


@dataclass
class ComputeCounters:
    expanded_nodes: int = 0
    bound_evals: int = 0
    generated_children: int = 0
    feasibility_checks: int = 0
    incumbent_evals: int = 0
    frontier_inserts: int = 0

    def to_dict(self) -> dict[str, int]:
        return {
            "expanded_nodes": int(self.expanded_nodes),
            "bound_evals": int(self.bound_evals),
            "generated_children": int(self.generated_children),
            "feasibility_checks": int(self.feasibility_checks),
            "incumbent_evals": int(self.incumbent_evals),
            "frontier_inserts": int(self.frontier_inserts),
        }

    def copy(self) -> ComputeCounters:
        return ComputeCounters(
            expanded_nodes=int(self.expanded_nodes),
            bound_evals=int(self.bound_evals),
            generated_children=int(self.generated_children),
            feasibility_checks=int(self.feasibility_checks),
            incumbent_evals=int(self.incumbent_evals),
            frontier_inserts=int(self.frontier_inserts),
        )

    def add(self, other: ComputeCounters) -> ComputeCounters:
        return ComputeCounters(
            expanded_nodes=int(self.expanded_nodes + other.expanded_nodes),
            bound_evals=int(self.bound_evals + other.bound_evals),
            generated_children=int(self.generated_children + other.generated_children),
            feasibility_checks=int(self.feasibility_checks + other.feasibility_checks),
            incumbent_evals=int(self.incumbent_evals + other.incumbent_evals),
            frontier_inserts=int(self.frontier_inserts + other.frontier_inserts),
        )

    def compute_value(self, weights: Mapping[str, int | float]) -> int:
        """Calculate deterministic compute unit C_i = sum_k omega_k * N_ik.
        
        Uses frozen integer nanosecond-per-operation weights.
        Returns non-negative integer compute units.
        """
        val = 0.0
        for k in COUNTER_NAMES:
            w = float(weights.get(k, 0))
            cnt = int(getattr(self, k, 0))
            val += w * cnt
        return max(0, int(round(val)))
