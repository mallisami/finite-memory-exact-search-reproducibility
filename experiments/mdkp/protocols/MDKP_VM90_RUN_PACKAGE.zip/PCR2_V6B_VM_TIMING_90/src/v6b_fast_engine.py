from __future__ import annotations
import math, pickle, time, hashlib
import numpy as np
from independent_mdkp.core import make_instance, initial_solution, objective_cost, make_context_library, make_context_trace, checkpoint_compatible, initialize_checkpoint, checkpoint_solution
from independent_mdkp.controller import HistoryRow, CompatStats, _feature_row, _history_recurrence_prob
from independent_mdkp.pcr_mdkp_engine import advance_checkpoint_gap_target, StoredMDKPSidecar, MDKPExecutionResult
from independent_mdkp.allocation import ValueItem, select_exact_expected_value
from compute_counters import ComputeCounters

P10=['history_count_same_context','iterations_since_last_context','recent_same_context_count_20','current_cost_ratio','current_best_cost_ratio','temperature_ratio','recent_accept_rate_10','recent_accept_rate_20','recent_moved_item_overlap_10','recent_moved_item_overlap_20','accepted_moves_since_context','cost_delta_since_context','objective_improvement_last_10','objective_improvement_last_20']
EXTRA=['invested_nodes_norm','size_ratio','frontier_log1p','stored_gap','stored_gap_finite','p_rec','best_profit_norm','residual_mean_ratio','residual_min_ratio']
FEATURES=P10+EXTRA

def _sigmoid(z: float) -> float:
    if z >= 0:
        e=math.exp(-z); return 1.0/(1.0+e)
    e=math.exp(z); return e/(1.0+e)

def predict_utility_fast(coeff, f):
    x=np.asarray([float(f[k]) for k in coeff['features']], dtype=float)
    c=coeff['classifier']; r=coeff['conditional_regressor']
    zc=float(np.dot((x-np.asarray(c['mean']))/np.asarray(c['scale']), np.asarray(c['coef'])) + c['intercept'])
    p=_sigmoid(zc)
    zr=float(np.dot((x-np.asarray(r['mean']))/np.asarray(r['scale']), np.asarray(r['coef'])) + r['intercept'])
    cond=float(np.clip(np.expm1(zr),0,float(coeff['clip_max'])))
    return float(np.clip(p*cond,0,float(coeff['clip_max']))),p,cond

def gap_feat(cp,ub):
    if not ub or any(math.isinf(float(v)) for v in ub): return 10.0,0.0
    u=max(float(v) for v in ub)
    return float(min(max((u-cp.best_profit)/max(abs(float(cp.best_profit)),1.0),0),10)),1.0

def run_direct_case(*,seed:int,coeff,value_mode='direct',n_items=168,destroy_size=54,iterations=200,context_count=18,budget_bytes=3068,n_dims=3,future_horizon=40,gap_target=.02,slice_cap=384,gap_check_interval=16,lazy_features=True):
    inst=make_instance(n_items,seed,n_dims=n_dims); x=initial_solution(inst); init=objective_cost(inst,x); best=init; contexts=make_context_library(n_items,destroy_size,seed,count=context_count); trace=make_context_trace(contexts,iterations,seed)
    history=[]; records={}; compat={}; global_compat=CompatStats(); branch=useful=reused=creations=cap_evict=invalid=0; ser=rest=sel=score=repair=0.; peak=byte_time=peak_live=live4=0; sizes=[]; accepted=0; total=ComputeCounters(); exact_ret=eps_ret=0; pred_values=[]; pred_probs=[]
    th=hashlib.sha256(); tw=time.perf_counter_ns(); tc=time.process_time_ns()
    for t,(ctx,ctx_class,u_accept) in enumerate(trace,1):
        before=objective_cost(inst,x); temp=max(1e-9,.02*abs(init)*(.995**(t-1))); feats=_feature_row(history,t,ctx,ctx_class,before,best,temp,init)
        rec=records.get(ctx); cp=None; resumed=False; ub=[math.inf]; cpc=ComputeCounters()
        if rec is not None:
            tt=time.perf_counter(); cand=pickle.loads(rec.blob); rest+=(time.perf_counter()-tt)*1000
            if checkpoint_compatible(inst,x,cand):
                cp=cand; resumed=True; useful+=1; reused+=int(rec.cumulative_nodes); cpc=rec.compute_counters.copy()
                if rec.frontier_ub_blob is not None:
                    tt=time.perf_counter(); ub=list(pickle.loads(rec.frontier_ub_blob)); rest+=(time.perf_counter()-tt)*1000
                s=compat.setdefault(ctx,CompatStats()); s.compatible+=1; global_compat.compatible+=1
            else:
                records.pop(ctx,None); invalid+=1; s=compat.setdefault(ctx,CompatStats()); s.incompatible+=1; global_compat.incompatible+=1
        if cp is None:
            cp=initialize_checkpoint(inst,x,ctx); creations+=1; cpc=ComputeCounters(incumbent_evals=1,frontier_inserts=1); ub=[math.inf]
        step=ComputeCounters(); tt=time.perf_counter(); _,_,expanded,exact,within=advance_checkpoint_gap_target(inst,cp,slice_cap,step,ub,gap_target,gap_check_interval); repair+=(time.perf_counter()-tt)*1000; branch+=int(expanded); exact_ret+=int(exact); eps_ret+=int((not exact) and within); retired=exact or within; cpc=cpc.add(step); total=total.add(step)
        if not resumed: total.incumbent_evals+=1; total.frontier_inserts+=1
        prop=checkpoint_solution(inst,x,cp); afterp=objective_cost(inst,prop); delta=afterp-before; accept=(delta<=0) or (u_accept<math.exp(-max(delta,0)/temp))
        if accept:
            moved=tuple(np.flatnonzero(prop!=x).astype(int).tolist()); x=prop; accepted+=1
            if objective_cost(inst,x)<best: best=objective_cost(inst,x)
        else: moved=()
        if not retired:
            tt=time.perf_counter(); blob=pickle.dumps(cp,protocol=pickle.HIGHEST_PROTOCOL); ubb=pickle.dumps(tuple(float(v) for v in ub),protocol=pickle.HIGHEST_PROTOCOL); ser+=(time.perf_counter()-tt)*1000; size=len(blob)+len(ubb); sizes.append(size)
            p_rec=_history_recurrence_prob(history,t,ctx,future_horizon)
            if value_mode=='empirical':
                s=compat.setdefault(ctx,CompatStats()); p=float(np.clip(p_rec*s.prob(global_compat),1e-6,1-1e-6)); val=float(p*cp.invested_nodes); pp=p
            else:
                sg,sgf=gap_feat(cp,ub); resid=np.asarray(cp.residual,dtype=float)/np.maximum(inst.capacities.astype(float),1.0); f=dict(feats); f.update(invested_nodes_norm=float(cp.invested_nodes/slice_cap),size_ratio=float(size/budget_bytes),frontier_log1p=float(math.log1p(len(cp.frontier))),stored_gap=sg,stored_gap_finite=sgf,p_rec=float(p_rec),best_profit_norm=float(cp.best_profit/max(abs(before),1.0)),residual_mean_ratio=float(resid.mean()),residual_min_ratio=float(resid.min()))
                tt=time.perf_counter(); val,pp,_=predict_utility_fast(coeff,f); score+=(time.perf_counter()-tt)*1000
            pred_values.append(val); pred_probs.append(pp); incoming=StoredMDKPSidecar(ctx,blob,size,val,int(cp.invested_nodes),t,cpc,ubb,len(ubb)); cand=dict(records); cand[ctx]=incoming; items=[ValueItem(k,v.size_bytes,v.expected_value) for k,v in cand.items()]; tt=time.perf_counter(); keep=set(select_exact_expected_value(items,budget_bytes=budget_bytes)); sel+=(time.perf_counter()-tt)*1000; cap_evict+=len(set(records)-keep); records={k:v for k,v in cand.items() if k in keep}
        else: records.pop(ctx,None)
        if accept and moved:
            bad=[]
            for k,r in list(records.items()):
                try:c=pickle.loads(r.blob)
                except:bad.append(k);continue
                if not checkpoint_compatible(inst,x,c):bad.append(k)
            for k in bad: records.pop(k,None)
            invalid+=len(bad)
        bn=sum(r.size_bytes for r in records.values()); peak=max(peak,bn); byte_time+=bn; peak_live=max(peak_live,len(records)); live4+=int(len(records)>=4); after=objective_cost(inst,x); history.append(HistoryRow(t,ctx,ctx_class,bool(accept),moved,float(before),float(after))); th.update(f'{t}:{int(accept)}:{after:.6f}:'.encode()); th.update(x.tobytes())
    tw2=time.perf_counter_ns(); tc2=time.process_time_ns(); pol='direct_utility' if value_mode=='direct' else 'empirical_pW_shadow'
    res=MDKPExecutionResult(seed=int(seed),n_items=n_items,n_dims=n_dims,destroy_size=destroy_size,slice_nodes=slice_cap,iterations=iterations,context_count=context_count,policy=pol,budget_bytes=budget_bytes,initial_cost=float(init),final_cost=float(objective_cost(inst,x)),best_cost=float(best),branch_nodes_executed=int(branch),useful_resumes=int(useful),reused_prior_nodes=int(reused),checkpoint_creations=int(creations),capacity_evictions=int(cap_evict),invalidation_evictions=int(invalid),peak_checkpoint_bytes=int(peak),byte_time=int(byte_time),peak_live_checkpoints=int(peak_live),fraction_iterations_live_ge4=float(live4/max(iterations,1)),mean_checkpoint_size_bytes=float(np.mean(sizes)) if sizes else 0,max_checkpoint_size_bytes=int(max(sizes) if sizes else 0),serialization_ms=float(ser),restoration_ms=float(rest),selection_ms=float(sel),model_scoring_ms=float(score),repair_search_ms=float(repair),accepted_moves=int(accepted),trajectory_hash=th.hexdigest(),end_to_end_wall_ns=int(tw2-tw),end_to_end_cpu_ns=int(tc2-tc),total_counters=total.to_dict(),slice_mode='gap_target',gap_target=float(gap_target),slice_cap=int(slice_cap),epsilon_retirements=int(eps_ret),exact_retirements=int(exact_ret),lazy_features=True)
    return res, {'mean_predicted_utility':float(np.mean(pred_values)) if pred_values else 0.0,'mean_positive_probability':float(np.mean(pred_probs)) if pred_probs else 0.0,'positive_value_count':int(sum(v>0 for v in pred_values)),'value_count':len(pred_values)}
