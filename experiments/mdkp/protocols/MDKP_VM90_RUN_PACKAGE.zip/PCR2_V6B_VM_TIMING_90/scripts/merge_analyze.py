from pathlib import Path
import csv,json,math,sys
import numpy as np
from scipy.stats import wilcoxon
root=Path(__file__).resolve().parents[1]; outdir=root/'outputs'; prot=json.load(open(root/'FROZEN_TIMING_PROTOCOL.json'))
files=[outdir/f'{vm}_raw.csv' for vm in prot['shards']]
missing=[str(p) for p in files if not p.exists()]
if missing: raise SystemExit('Missing shard outputs: '+', '.join(missing))
rows=[]
for p in files:
 with p.open(newline='') as f: rows += list(csv.DictReader(f))
expected=prot['n_cases']*len(prot['policies'])*prot['repetitions_per_case_policy']
if len(rows)!=expected: raise SystemExit(f'Expected {expected} rows, found {len(rows)}')
# type conversions
num=['global_case_index','vm_case_index','seed','repetition','position','branches','final_cost','best_cost','wall_ms','cpu_ms','repair_search_ms','model_scoring_ms']
for r in rows:
 for k in num: r[k]=float(r[k]) if k not in ['global_case_index','vm_case_index','seed','repetition','position','branches'] else int(float(r[k]))
# completeness and deterministic node guard
by={}
for r in rows: by.setdefault((r['vm_id'],r['global_case_index'],r['policy']),[]).append(r)
for k,v in by.items():
 if len(v)!=prot['repetitions_per_case_policy']: raise SystemExit(f'bad repetition count {k}: {len(v)}')
 if len({x['branches'] for x in v})!=1: raise SystemExit(f'NONDETERMINISTIC NODE COUNT {k}')
# case-policy medians
med={}
for k,v in by.items():
 med[k]={'wall_ms':float(np.median([x['wall_ms'] for x in v])),'cpu_ms':float(np.median([x['cpu_ms'] for x in v])),'branches':v[0]['branches'],'final_cost':v[0]['final_cost'],'best_cost':v[0]['best_cost']}
# build 90 cases
cases=[]
for vm in prot['shards']:
 gis=sorted({g for (vv,g,p) in med if vv==vm})
 for g in gis:
  cases.append({'vm':vm,'case':g,**{p:med[(vm,g,p)] for p in prot['policies']}})
if len(cases)!=prot['n_cases']: raise SystemExit('case count mismatch')

def contrast(a,b,metric='wall_ms',B=10000,seed=202610111001):
 vals=np.array([math.log(c[a][metric]/c[b][metric]) for c in cases],float)
 est=float(math.exp(vals.mean()))
 rng=np.random.default_rng(seed); boots=[]
 strata={vm:[i for i,c in enumerate(cases) if c['vm']==vm] for vm in prot['shards']}
 for _ in range(B):
  idx=[]
  for vm,ii in strata.items(): idx.extend(rng.choice(ii,size=len(ii),replace=True).tolist())
  boots.append(math.exp(float(vals[idx].mean())))
 lo,hi=np.quantile(boots,[.025,.975]); w=int(np.sum(vals<0)); t=int(np.sum(vals==0)); l=int(np.sum(vals>0))
 try: p=float(wilcoxon(vals,alternative='two-sided',zero_method='wilcox').pvalue)
 except Exception: p=float('nan')
 return {'ratio':est,'ci95':[float(lo),float(hi)],'wins_a_faster':w,'ties':t,'losses_a_slower':l,'wilcoxon_p_two_sided':p,'n_cases':len(vals)}
res={'study_id':prot['study_id'],'rows':len(rows),'cases':len(cases),'repetitions':prot['repetitions_per_case_policy'],'primary_wall_direct_vs_empirical':contrast('direct_utility','empirical_pW','wall_ms',seed=202610111001),'secondary_wall_direct_vs_restart':contrast('direct_utility','restart','wall_ms',seed=202610111002),'cpu_direct_vs_empirical':contrast('direct_utility','empirical_pW','cpu_ms',seed=202610111003),'nodes_direct_vs_empirical':contrast('direct_utility','empirical_pW','branches',seed=202610111004)}
# machine-stratified estimates are primary; also expose per-VM paired summaries for heterogeneity checks
res['per_vm_wall_direct_vs_empirical']={}
for vm in prot['shards']:
    sub=[c for c in cases if c['vm']==vm]
    vals=np.array([math.log(c['direct_utility']['wall_ms']/c['empirical_pW']['wall_ms']) for c in sub],float)
    res['per_vm_wall_direct_vs_empirical'][vm]={'ratio':float(math.exp(vals.mean())),'wins_direct_faster':int(np.sum(vals<0)),'ties':int(np.sum(vals==0)),'losses_direct_slower':int(np.sum(vals>0)),'n_cases':len(sub)}
# solution quality differences
fd=np.array([c['direct_utility']['final_cost']-c['empirical_pW']['final_cost'] for c in cases],float)
res['solution_quality_direct_minus_empirical']={'same':int(np.sum(fd==0)),'direct_better':int(np.sum(fd<0)),'direct_worse':int(np.sum(fd>0)),'mean_diff':float(fd.mean()),'max_abs_diff':float(np.abs(fd).max())}
json.dump(res,open(outdir/'FINAL_ANALYSIS.json','w'),indent=2,sort_keys=True)
# merged raw
with open(outdir/'MERGED_RAW.csv','w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=rows[0].keys());w.writeheader();w.writerows(rows)
print(json.dumps(res,indent=2))
