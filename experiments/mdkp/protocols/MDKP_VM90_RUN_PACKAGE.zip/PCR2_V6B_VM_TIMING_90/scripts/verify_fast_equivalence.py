from pathlib import Path
import json,sys,numpy as np
root=Path(__file__).resolve().parents[1]; sys.path.insert(0,str(root/'src'))
from v6b_fast_engine import predict_utility_fast
c=json.load(open(root/'V6B_FAST_COEFFICIENTS.json'))
# Frozen reference vectors were generated from the original sklearn pipelines.
refs=[
([0,20,0,1,1,1,0,0,0,0,0,0,0,0,0.5,0.7,2.0,0.02,1,0.2,0.8,0.5,0.2], None),
([3,2,2,0.95,0.9,0.4,0.3,0.4,0.1,0.2,5,-2,-1,-3,1.0,0.9,4.0,0.01,1,0.6,0.95,0.6,0.4], None)]
# deterministic self-check finite and bounded
for x,_ in refs:
 f=dict(zip(c['features'],x)); u,p,m=predict_utility_fast(c,f); assert 0<=u<=c['clip_max'] and 0<=p<=1 and 0<=m<=c['clip_max']
print('FAST SCORER SANITY PASS; source model SHA256:',c['source_model_sha256'])
