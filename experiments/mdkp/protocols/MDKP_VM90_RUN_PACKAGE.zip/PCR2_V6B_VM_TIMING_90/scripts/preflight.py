from pathlib import Path
import argparse, json, os, platform, subprocess, sys, hashlib, time
import numpy as np
ap=argparse.ArgumentParser(); ap.add_argument('--vm',required=True); ap.add_argument('--outdir',default='outputs'); a=ap.parse_args()
root=Path(__file__).resolve().parents[1]; out=root/a.outdir; out.mkdir(exist_ok=True)
prot=json.load(open(root/'FROZEN_TIMING_PROTOCOL.json'))
if a.vm not in prot['machine_plan']: raise SystemExit(f'Unknown VM id {a.vm}')
def cmd(x):
    try:return subprocess.check_output(x,shell=True,text=True,stderr=subprocess.STDOUT).strip()
    except Exception as e:return f'UNAVAILABLE: {e}'
mem='';
try:
    for line in open('/proc/meminfo'):
        if line.startswith('MemTotal:'): mem=line.strip(); break
except: pass
meta={'vm_id':a.vm,'utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'hostname':platform.node(),'platform':platform.platform(),'python':sys.version,'numpy':np.__version__,'cpu_count':os.cpu_count(),'loadavg':list(os.getloadavg()) if hasattr(os,'getloadavg') else None,'memtotal':mem,'lscpu':cmd('lscpu'),'uname':cmd('uname -a'),'taskset':cmd('taskset -pc $$'),'env_threads':{k:os.environ.get(k) for k in ['OMP_NUM_THREADS','MKL_NUM_THREADS','OPENBLAS_NUM_THREADS','NUMEXPR_NUM_THREADS']}}
for f in ['FROZEN_TIMING_PROTOCOL.json','V6B_FAST_COEFFICIENTS.json','src/v6b_fast_engine.py','src/independent_mdkp/pcr_mdkp_engine.py']:
    b=(root/f).read_bytes(); meta.setdefault('sha256',{})[f]=hashlib.sha256(b).hexdigest()
json.dump(meta,open(out/f'{a.vm}_environment.json','w'),indent=2,sort_keys=True)
print(json.dumps({k:meta[k] for k in ['vm_id','hostname','cpu_count','loadavg','memtotal']},indent=2))
exp=prot['machine_plan'][a.vm]['expected_vcpu']
if os.cpu_count()!=exp: print(f'WARNING: expected {exp} vCPU, observed {os.cpu_count()}',file=sys.stderr)
print('PREFLIGHT RECORDED')
