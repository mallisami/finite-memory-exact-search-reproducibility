from pathlib import Path
import json,sys
root=Path(__file__).resolve().parents[1];sys.path.insert(0,str(root/'src'))
from independent_mdkp.pcr_mdkp_engine import run_mdkp_campaign_case
from v6b_fast_engine import run_direct_case
p=json.load(open(root/'FROZEN_TIMING_PROTOCOL.json')); c=json.load(open(root/'V6B_FAST_COEFFICIENTS.json')); s=p['warmup_seeds']['vm1_2vcpu_8gb'][0]; st=p['scientific_settings']
r=run_mdkp_campaign_case(seed=s,policy='empirical_pW',n_items=st['n_items'],destroy_size=st['destroy_size'],context_count=st['context_count'],budget_bytes=st['budget_bytes'],slice_mode='gap_target',gap_target=st['gap_target'],slice_cap=st['slice_cap'],gap_check_interval=st['gap_check_interval'],lazy_features=True,iterations=st['iterations'])
d,_=run_direct_case(seed=s,coeff=c,value_mode='direct',**st)
print('SMOKE PASS',{'seed':s,'empirical_nodes':r.branch_nodes_executed,'direct_nodes':d.branch_nodes_executed,'direct_peak_bytes':d.peak_checkpoint_bytes})
