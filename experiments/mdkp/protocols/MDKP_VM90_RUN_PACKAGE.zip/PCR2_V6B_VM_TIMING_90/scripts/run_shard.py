from pathlib import Path
import argparse,csv,gc,json,os,sys,time,hashlib
root=Path(__file__).resolve().parents[1]; sys.path.insert(0,str(root/'src'))
from independent_mdkp.pcr_mdkp_engine import run_mdkp_campaign_case
from v6b_fast_engine import run_direct_case
ap=argparse.ArgumentParser(); ap.add_argument('--vm',required=True); ap.add_argument('--outdir',default='outputs'); a=ap.parse_args()
prot=json.load(open(root/'FROZEN_TIMING_PROTOCOL.json')); coeff=json.load(open(root/'V6B_FAST_COEFFICIENTS.json'))
if a.vm not in prot['shards']: raise SystemExit(f'unknown vm {a.vm}')
outdir=root/a.outdir; outdir.mkdir(exist_ok=True); out=outdir/f'{a.vm}_raw.csv'
settings=prot['scientific_settings']; policies=prot['policies']; reps=int(prot['repetitions_per_case_policy']); seeds=prot['shards'][a.vm]
# refuse concurrent invocation on same output
lock=outdir/f'.{a.vm}.lock'
try:
    fd=os.open(lock,os.O_CREAT|os.O_EXCL|os.O_WRONLY); os.write(fd,str(os.getpid()).encode()); os.close(fd)
except FileExistsError: raise SystemExit(f'Lock exists: {lock}. Ensure another timed runner is not active.')
fields=['study_id','vm_id','global_case_index','vm_case_index','seed','repetition','position','policy','branches','useful_resumes','reused_prior_nodes','capacity_evictions','invalidation_evictions','peak_bytes','epsilon_retirements','exact_retirements','final_cost','best_cost','trajectory_hash','wall_ms','cpu_ms','repair_search_ms','model_scoring_ms','selection_ms','serialization_ms','restoration_ms','mean_predicted_utility','mean_positive_probability','positive_value_count','value_count','utc_finished']
try:
    # warm-up is excluded from raw output and analysis
    print('Warm-up starting...',flush=True)
    for ws in prot['warmup_seeds'][a.vm]:
        run_mdkp_campaign_case(seed=ws,policy='restart',n_items=settings['n_items'],destroy_size=settings['destroy_size'],context_count=settings['context_count'],budget_bytes=settings['budget_bytes'],slice_mode='gap_target',gap_target=settings['gap_target'],slice_cap=settings['slice_cap'],gap_check_interval=settings['gap_check_interval'],lazy_features=True,iterations=settings['iterations'])
        run_direct_case(seed=ws,coeff=coeff,value_mode='direct',**settings)
    print('Warm-up complete.',flush=True)
    existing=set(); exists=out.exists() and out.stat().st_size>0
    if exists:
        with out.open(newline='') as f:
            for r in csv.DictReader(f): existing.add((int(r['vm_case_index']),int(r['repetition']),r['policy']))
    with out.open('a',newline='') as f:
        w=csv.DictWriter(f,fieldnames=fields)
        if not exists: w.writeheader(); f.flush(); os.fsync(f.fileno())
        offset={'vm1_2vcpu_8gb':0,'vm2_4vcpu_16gb':30,'vm3_4vcpu_16gb':60}[a.vm]
        for ci,seed in enumerate(seeds):
            gi=offset+ci
            for rep in range(reps):
                order=policies[(gi+rep)%3:]+policies[:(gi+rep)%3]
                for pos,pol in enumerate(order):
                    key=(ci,rep,pol)
                    if key in existing: continue
                    gc.collect(); time.sleep(0.05)
                    if pol=='direct_utility':
                        r,st=run_direct_case(seed=seed,coeff=coeff,value_mode='direct',**settings)
                    else:
                        r=run_mdkp_campaign_case(seed=seed,policy=pol,n_items=settings['n_items'],destroy_size=settings['destroy_size'],context_count=settings['context_count'],budget_bytes=settings['budget_bytes'],slice_mode='gap_target',gap_target=settings['gap_target'],slice_cap=settings['slice_cap'],gap_check_interval=settings['gap_check_interval'],lazy_features=True,iterations=settings['iterations'])
                        st={'mean_predicted_utility':0.0,'mean_positive_probability':0.0,'positive_value_count':0,'value_count':0}
                    row={'study_id':prot['study_id'],'vm_id':a.vm,'global_case_index':gi,'vm_case_index':ci,'seed':seed,'repetition':rep+1,'position':pos,'policy':pol,'branches':r.branch_nodes_executed,'useful_resumes':r.useful_resumes,'reused_prior_nodes':r.reused_prior_nodes,'capacity_evictions':r.capacity_evictions,'invalidation_evictions':r.invalidation_evictions,'peak_bytes':r.peak_checkpoint_bytes,'epsilon_retirements':r.epsilon_retirements,'exact_retirements':r.exact_retirements,'final_cost':r.final_cost,'best_cost':r.best_cost,'trajectory_hash':r.trajectory_hash,'wall_ms':r.end_to_end_wall_ns/1e6,'cpu_ms':r.end_to_end_cpu_ns/1e6,'repair_search_ms':r.repair_search_ms,'model_scoring_ms':r.model_scoring_ms,'selection_ms':r.selection_ms,'serialization_ms':r.serialization_ms,'restoration_ms':r.restoration_ms,**st,'utc_finished':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())}
                    w.writerow(row); f.flush(); os.fsync(f.fileno()); existing.add(key)
                    print(f'{a.vm} case={ci+1}/{len(seeds)} rep={rep+1}/{reps} pol={pol} wall={row["wall_ms"]:.1f}ms nodes={row["branches"]}',flush=True)
    print(f'COMPLETE {a.vm}: {out}',flush=True)
finally:
    try: lock.unlink()
    except: pass
