# PCR Paper-II — V6B controlled VM timing validation

This package runs the **frozen direct marginal-work retention method** on **90 completely new unseen MDKP cases** to test whether its already-confirmed reduction in executed search work converts into lower wall-clock runtime.

## Frozen design

- 90 new cases total, fixed before VM execution.
- 30 cases per VM.
- Policies: `restart`, `empirical_pW`, `direct_utility`.
- Five timed repetitions of every policy on every case.
- All three policies for a case run on the **same VM**, with cyclic order rotation across repetitions.
- Primary timing endpoint: geometric mean of the case-level median wall-time ratio `direct_utility / empirical_pW`.
- 10,000-resample VM-stratified bootstrap CI; paired two-sided Wilcoxon is also reported.
- No case may be added, removed, replaced, or rerun selectively based on its result.

Scientific settings are frozen at: byte budget 3068, gap target 0.02, slice cap 384, gap-check interval 16, 200 outer iterations, 168 items, 54-item destroy size, 18 contexts.

## Why three VMs are valid

The study uses **paired within-case ratios**. Each case and all of its policies stay on one machine. Absolute times from different VM types are not compared directly. The final bootstrap preserves VM strata, so machine-specific baseline speed is treated as a block rather than ignored.

Do **not** run two timed workers simultaneously on the same VM. More vCPUs do not justify concurrent timing jobs because they would introduce scheduler/cache/memory contention. The speedup comes from running the three VMs concurrently.

## VM assignment

- `vm1_2vcpu_8gb`: 30 cases
- `vm2_4vcpu_16gb`: 30 cases
- `vm3_4vcpu_16gb`: 30 cases

The 8-GB VM is sufficient because the campaign is sequential and checkpoint memory is tiny relative to host RAM. Keep other user workloads stopped during the timed run.

## Setup on each Ubuntu/Linux VM

Copy the same ZIP to each VM and run:

```bash
unzip PCR2_V6B_VM_TIMING_90.zip
cd PCR2_V6B_VM_TIMING_90
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
pip install -r requirements.txt
python scripts/smoke_test.py
```

The smoke test uses non-confirmatory warm-up data and is excluded from analysis.

## Start all three VMs at approximately the same time

VM 1 (2 vCPU / 8 GB):

```bash
source .venv/bin/activate
bash run_vm1_2vcpu_8gb.sh |& tee outputs/vm1_console.log
```

VM 2 (4 vCPU / 16 GB):

```bash
source .venv/bin/activate
bash run_vm2_4vcpu_16gb.sh |& tee outputs/vm2_console.log
```

VM 3 (4 vCPU / 16 GB):

```bash
source .venv/bin/activate
bash run_vm3_4vcpu_16gb.sh |& tee outputs/vm3_console.log
```

The runner flushes every completed policy run to CSV, so an accidental SSH disconnect does not lose completed work. If the Python process itself stops, rerunning the same shell script resumes missing rows. Do not delete completed rows.

## Files to collect after completion

From VM 1:

- `outputs/vm1_2vcpu_8gb_raw.csv`
- `outputs/vm1_2vcpu_8gb_environment.json`
- `outputs/vm1_console.log`

From VM 2:

- `outputs/vm2_4vcpu_16gb_raw.csv`
- `outputs/vm2_4vcpu_16gb_environment.json`
- `outputs/vm2_console.log`

From VM 3:

- `outputs/vm3_4vcpu_16gb_raw.csv`
- `outputs/vm3_4vcpu_16gb_environment.json`
- `outputs/vm3_console.log`

Place all six data/environment files into the `outputs/` directory of one package copy and run:

```bash
source .venv/bin/activate
python scripts/merge_analyze.py | tee outputs/final_analysis_console.txt
```

It will refuse incomplete campaigns. Expected primary raw count is:

`90 cases × 3 policies × 5 repetitions = 1,350 rows`.

## Timing estimate

The preceding 45-case run in the chat execution environment averaged about **6.93 seconds per case for one three-policy pass**. Five repetitions therefore correspond to roughly **34.7 seconds per case** before VM-specific slowdown and small runner pauses.

At 30 cases per VM, the observed-equivalent compute time is about **17–18 minutes per VM**. A practical expectation is roughly **20–45 minutes**, and allowing for slower/noisier cloud CPUs, **up to about an hour** is a reasonable conservative envelope. The three VMs run simultaneously, so their times do not add together.

This is an estimate from prior execution, not a guaranteed duration.

## Maximum case count

There is no meaningful RAM-limited maximum for these machines when cases are run sequentially. Hundreds of cases are technically possible. For this paper, however, **90 new cases is the frozen primary timing study**. Increasing the count after observing interim results would invalidate the predeclared stopping rule. If a later replication is desired, it should be a separately frozen study rather than an extension of these 90 cases.

## Fast scorer

The runtime package uses an algebraically equivalent coefficient-only implementation of the frozen V6B two-part model. It was checked on all 1,948 development rows (maximum component difference `2.84e-14`) and on five dynamic campaign seeds with identical executed nodes, final costs, and trajectory hashes. No retraining or scientific model change was performed.
