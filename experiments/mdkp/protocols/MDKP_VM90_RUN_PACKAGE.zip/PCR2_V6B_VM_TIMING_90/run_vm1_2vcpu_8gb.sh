#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
export OMP_NUM_THREADS=1
export MKL_NUM_THREADS=1
export OPENBLAS_NUM_THREADS=1
export NUMEXPR_NUM_THREADS=1
python scripts/preflight.py --vm vm1_2vcpu_8gb
if command -v taskset >/dev/null 2>&1; then
  taskset -c 0 python scripts/run_shard.py --vm vm1_2vcpu_8gb
else
  python scripts/run_shard.py --vm vm1_2vcpu_8gb
fi
